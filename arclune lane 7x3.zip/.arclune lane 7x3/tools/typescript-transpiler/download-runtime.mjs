import https from 'https';
import { createWriteStream } from 'fs';
import { mkdir, writeFile } from 'fs/promises';
import { dirname, resolve } from 'path';
import { fileURLToPath } from 'url';

const RUNTIME_URL = 'https://unpkg.com/typescript@5.4.5/lib/typescript.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
const vendorDir = resolve(__dirname, 'vendor');
const outputPath = resolve(vendorDir, 'typescript.js');

await mkdir(vendorDir, { recursive: true });

function download(url, dest) {
  return new Promise((resolvePromise, rejectPromise) => {
    https
      .get(url, (response) => {
        if (response.statusCode && response.statusCode >= 300 && response.statusCode < 400 && response.headers.location) {
          const redirectUrl = new URL(response.headers.location, url).toString();
          response.resume();
          download(redirectUrl, dest).then(resolvePromise, rejectPromise);
          return;
        }

        if (response.statusCode !== 200) {
          rejectPromise(new Error(`Request failed with status code ${response.statusCode}`));
          response.resume();
          return;
        }

        const fileStream = createWriteStream(dest);
        fileStream.on('error', (error) => {
          rejectPromise(error);
        });
        fileStream.on('finish', () => {
          resolvePromise();
        });
        response.on('error', rejectPromise);
        response.pipe(fileStream);
      })
      .on('error', rejectPromise);
  });
}

const FALLBACK_RUNTIME = `"use strict";
const ModuleKind = Object.freeze({
  None: "none",
  CommonJS: "commonjs",
  ES2015: "esm",
  ES2020: "esm",
  ES2022: "esm",
  ESNext: "esm",
});
const ScriptTarget = Object.freeze({
  ES3: "es2015",
  ES5: "es2015",
  ES2015: "es2015",
  ES2016: "es2016",
  ES2017: "es2017",
  ES2018: "es2018",
  ES2019: "es2019",
  ES2020: "es2020",
  ES2021: "es2021",
  ES2022: "es2022",
  ESNext: "esnext",
});
const JsxEmit = Object.freeze({
  None: "none",
  Preserve: "preserve",
  React: "transform",
  ReactNative: "transform",
  ReactJSX: "automatic",
  ReactJSXDev: "automatic",
});
const DiagnosticCategory = Object.freeze({
  Warning: 0,
  Error: 1,
  Suggestion: 2,
  Message: 3,
});
function flattenDiagnosticMessageText(message) {
  if (message == null) {
    return "";
  }
  return Array.isArray(message) ? message.join(String.fromCharCode(10)) : String(message);
}
function mapTarget(tsTarget) {
  return ScriptTarget[tsTarget] || "esnext";
}
function mapModule(tsModule) {
  switch (tsModule) {
    case ModuleKind.CommonJS:
      return "cjs";
    default:
      return "esm";
  }
}
function mapJsx(tsJsx) {
  switch (tsJsx) {
    case JsxEmit.Preserve:
      return "preserve";
    case JsxEmit.React:
    case JsxEmit.ReactNative:
      return "transform";
    case JsxEmit.ReactJSX:
    case JsxEmit.ReactJSXDev:
      return "automatic";
    default:
      return "none";
  }
}
function createMissingTypescriptError() {
  const error = new Error(
    'Không tìm thấy runtime TypeScript thật. Hãy sao chép thư mục "node_modules/typescript" từ một máy đã cài đầy đủ hoặc cài TypeScript trước khi bundle.',
  );
  error.code = "MISSING_TYPESCRIPT_RUNTIME";
  return error;
}
function transpileModule() {
  throw createMissingTypescriptError();
}
module.exports = {
  transpileModule,
  ModuleKind,
  ScriptTarget,
  JsxEmit,
  DiagnosticCategory,
  flattenDiagnosticMessageText,
};
`;

try {
  await download(RUNTIME_URL, outputPath);
  console.log(`Downloaded TypeScript runtime to ${outputPath}`);
} catch (error) {
  console.warn(`Failed to download TypeScript runtime: ${(error && error.message) || error}`);
  await writeFile(outputPath, FALLBACK_RUNTIME, 'utf8');
  console.log(`Wrote fallback runtime to ${outputPath}`);
}