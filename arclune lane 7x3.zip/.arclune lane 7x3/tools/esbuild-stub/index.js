const path = require('path');
let ts;

function getTypeScriptTranspiler() {
  if (!ts) {
    ts = require('typescript-transpiler');
  }
  return ts;
}

function initializationError() {
  return new Error('esbuild stub initialization cycle');
}

function createIdentitySourceMap(code, sourcefile = '<stdin>') {
  return JSON.stringify({
    version: 3,
    sources: [sourcefile],
    names: [],
    mappings: '',
    sourcesContent: [code],
  });
}

function performTransform(code, options = {}) {
  if (typeof code !== 'string') {
    throw new TypeError('esbuild stub transform expects code string');
  }
  const { loader, sourcemap, sourcefile } = options;
  const generateMap = Boolean(sourcemap);

  if (loader === 'ts' || loader === 'tsx') {
    const ts = getTypeScriptTranspiler();
    const compilerOptions = {
      module: ts.ModuleKind.ESNext,
      target: ts.ScriptTarget.ES2019,
      sourceMap: generateMap,
    };
    if (loader === 'tsx') {
      compilerOptions.jsx = ts.JsxEmit.React;
    }
    const fileName = sourcefile || (loader === 'tsx' ? 'stdin.tsx' : 'stdin.ts');
    let transpileResult;
    try {
      transpileResult = ts.transpileModule(code, {
        compilerOptions,
        fileName,
        reportDiagnostics: true,
      });
    } catch (err) {
      if (err && (err.code === 'MISSING_TYPESCRIPT_RUNTIME' || err.name === 'MISSING_TYPESCRIPT_RUNTIME')) {
        throw Object.assign(
          new Error(
            'Không thể transpile TypeScript vì thiếu runtime TypeScript. Hãy sao chép thư mục "node_modules/typescript" từ một máy đã cài npm install hoặc cài đặt thủ công trước khi bundle.',
          ),
          { cause: err },
        );
      }
      throw err;
    }
    const warnings = (transpileResult.diagnostics || []).map((diagnostic) => {
      const message = ts.flattenDiagnosticMessageText(diagnostic.messageText, '\n');
      let location = null;
      if (diagnostic.file && typeof diagnostic.start === 'number') {
        const { line, character } = diagnostic.file.getLineAndCharacterOfPosition(
          diagnostic.start
        );
        location = {
          file: diagnostic.file.fileName,
          line: line + 1,
          column: character + 1,
        };
      } else if (sourcefile) {
        location = {
          file: sourcefile,
          line: 1,
          column: 1,
        };
      }
      return {
        text: message,
        level: diagnostic.category === ts.DiagnosticCategory.Error ? 'error' : 'warning',
        location,
      };
    });
    let outputCode = transpileResult.outputText;
    const mapText = generateMap ? transpileResult.sourceMapText || null : null;
    if (mapText && sourcemap === 'inline') {
      const inlineComment = `\n//# sourceMappingURL=data:application/json;base64,${Buffer.from(mapText, 'utf8').toString('base64')}`;
      outputCode += inlineComment;
    }
    return {
      code: outputCode,
      map: mapText,
      warnings,
    };
  }

  const mapText = generateMap ? createIdentitySourceMap(code, sourcefile) : null;
  let outputCode = code;
  if (mapText && sourcemap === 'inline') {
    const inlineComment = `\n//# sourceMappingURL=data:application/json;base64,${Buffer.from(mapText, 'utf8').toString('base64')}`;
    outputCode += inlineComment;
  }
  return {
    code: outputCode,
    map: mapText,
    warnings: [],
  };
}

async function transform(code, options = {}) {
  return performTransform(code, options);
}

function transformSync(code, options = {}) {
  return performTransform(code, options);
}

async function build(options = {}) {
  const { stdin, write = true, metafile } = options;
  if (!stdin || typeof stdin.contents !== 'string') {
    throw initializationError();
  }
  if (write) {
    throw initializationError();
  }
  const text = stdin.contents;
  const transformed = await transform(text, {
    loader: stdin.loader,
    sourcemap: options.sourcemap,
    sourcefile: stdin.sourcefile,
  });
  const outputText = transformed.code;
  const outputPath = options.outfile
    ? options.outfile
    : options.outdir
      ? path.join(options.outdir, stdin.sourcefile || 'stdin.js')
      : stdin.sourcefile || '<stdout>';
  const buffer = Buffer.from(outputText, 'utf8');
  const outputFiles = [
    {
      path: outputPath,
      text: outputText,
      contents: buffer,
    },
  ];
  if (transformed.map && options.sourcemap === 'external') {
    const mapPath = `${outputPath}.map`;
    outputFiles.push({
      path: mapPath,
      text: transformed.map,
      contents: Buffer.from(transformed.map, 'utf8'),
    });
  }
  const result = {
    outputFiles,
    warnings: transformed.warnings || [],
  };
  if (metafile) {
    const inputPath = stdin.sourcefile || '<stdin>';
    result.metafile = {
      inputs: {
        [inputPath]: {
          bytes: Buffer.byteLength(stdin.contents, 'utf8'),
        },
      },
      outputs: {
        [outputPath]: {
          bytes: buffer.byteLength,
          inputs: {
            [inputPath]: {
              bytesInOutput: buffer.byteLength,
            },
          },
        },
      },
    };
  }
  return result;
}

module.exports = {
  transform,
  transformSync,
  build,
};

module.exports.__arcStub = true;